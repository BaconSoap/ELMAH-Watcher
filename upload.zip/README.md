ELMAH-Watcher
=============

Chrome Extension to monitor ELMAH Error Logs and notify on new errors.
